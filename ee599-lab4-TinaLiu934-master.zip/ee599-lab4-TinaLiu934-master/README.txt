Name: Jingwen Liu
email: liu934@usc.edu
ID: 4261298599


PART 3:

student@studentVM:~/ee599/lab4$ g++ -o fibonacci_dp fibonacci_dp.cpp
student@studentVM:~/ee599/lab4$ ./fibonacci_dp
Please enter a number: 
10
running_time is: 0.001
The Nth Fibonacci number is: 34
student@studentVM:~/ee599/lab4$ g++ -o fibonacci_recursive fibonacci_recursive.cpp
student@studentVM:~/ee599/lab4$ ./fibonacci_recursive
Please enter a number: 
10
N is: 10
The Nth Fibonacci number is: 34
running_time is: 0
student@studentVM:~/ee599/lab4$ g++ -o fibonacci_dp fibonacci_dp.cpp
student@studentVM:~/ee599/lab4$ ./fibonacci_dp
Please enter a number: 
2000
running_time is: 0.013
The Nth Fibonacci number is: 5996186058873420925
student@studentVM:~/ee599/lab4$ g++ -o fibonacci_recursive fibonacci_recursive.cpp
student@studentVM:~/ee599/lab4$ ./fibonacci_recursive
Please enter a number: 
2000
N is: 2000
The Nth Fibonacci number is: 5996186058873420925
running_time is: 0.045

The complexity of dynamic programming is O(n), The complexity of dynamic programming is O(2^n).
In recursive method, when N change frome 10 to 2000, the running time change to 0.045ms.