#include <iostream>
#include <time.h>
using namespace std;

long Fibonacci(long a, long b, int n) {

	if (n >1) {
		return Fibonacci(a+b, a, n - 1);
	}
	else return a;

}

int main() {
   
   int N;
	long k;
	cout << "Please enter a number: "<< endl;
	cin>> N;
	time_t start, end;
   start = clock();

	k = Fibonacci(0,1,N);
	end = clock();

	cout <<"N is: "<< N <<endl;
	cout << "The Nth Fibonacci number is: "<< k << endl;
	
	double running_time = (double)(end - start)/CLOCKS_PER_SEC*1000;
	cout <<"running_time is: "<<running_time<<endl;
	return 0;

}



