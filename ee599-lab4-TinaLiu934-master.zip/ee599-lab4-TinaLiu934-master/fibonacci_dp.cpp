#include <iostream>
#include <time.h>
using namespace std;


int main() {
   time_t start, end;
	int N;
	long *f=new long[N];
	cout << "Please enter a number: "<< endl;
	cin>> N;
	
   f[0] = (long)0;
	f[1] = (long)1;
	
   start = clock();
   for (int i = 2; i < N; i++) {
        f[i] = f[i - 1] + f[i - 2];
   }
   end = clock();
   double running_time = (double)(end - start)/CLOCKS_PER_SEC*1000;
   cout <<"running_time is: "<<running_time<<endl;
    
   cout << "The Nth Fibonacci number is: "<< f[N-1] << endl;

}

